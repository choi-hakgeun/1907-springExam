package di_step1;

public class MsSql {
	public void getId() {
		System.out.println("mc.....");
	}
}
