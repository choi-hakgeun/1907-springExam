package di_step1;

public class Oracle {
	public void getName() {
		System.out.println("hong...");
	}
}
