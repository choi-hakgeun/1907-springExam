package di_step1;

public class MySql {
	public void getIrum() {
		System.out.println("kim...");
	}
}
