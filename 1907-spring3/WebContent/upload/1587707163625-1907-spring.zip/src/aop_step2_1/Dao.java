package aop_step2_1;

public interface Dao {
	public void select();
	public void view();
	public void modify();	
	public void insert();
	public void delete();
}
