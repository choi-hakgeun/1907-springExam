package di_anno;

public interface DB {
	public void getIrum();
}
