package di_anno;

public class MsSql implements DB{
	public void getIrum() {
		System.out.println("mc.....");
	}
}
