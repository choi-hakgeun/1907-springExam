package di_autowire;

public interface DB {
	public void getIrum();
}
