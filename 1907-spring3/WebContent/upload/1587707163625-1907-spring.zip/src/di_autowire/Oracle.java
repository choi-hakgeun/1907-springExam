package di_autowire;

public class Oracle implements DB {

	@Override
	public void getIrum() {
		System.out.println("hong...");

	}

}
