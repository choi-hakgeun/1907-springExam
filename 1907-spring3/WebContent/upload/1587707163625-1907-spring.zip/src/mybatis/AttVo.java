package mybatis;

public class AttVo {
	int serial;
	int pSerail; 
	String oriFile = "";
	String sysFile = "";
	
	public int getSerial() { return serial; }
	public void setSerial(int serial) { this.serial = serial; }
	public int getpSerail() { return pSerail; }
	public void setpSerail(int pSerail) { this.pSerail = pSerail; }
	public String getOriFile() { return oriFile; }
	public void setOriFile(String oriFile) { this.oriFile = oriFile; }
	public String getSysFile() { return sysFile; }
	public void setSysFile(String sysFile) { this.sysFile = sysFile; }
		
}
