package di_step4;

public interface DB {
	public void getIrum();
}
