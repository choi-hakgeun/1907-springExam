package di_step3;

public class MySql implements DB {

	@Override
	public void getIrum() {
		System.out.println("kim...");

	}

}
