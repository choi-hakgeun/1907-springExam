package di_step3;

public interface DB {
	public void getIrum();
}
