package di_step3;

public class Oracle implements DB {

	@Override
	public void getIrum() {
		System.out.println("hong...");

	}

}
