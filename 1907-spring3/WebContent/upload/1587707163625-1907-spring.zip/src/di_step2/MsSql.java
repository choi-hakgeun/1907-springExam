package di_step2;

public class MsSql implements DB{
	public void getIrum() {
		System.out.println("mc.....");
	}
}
