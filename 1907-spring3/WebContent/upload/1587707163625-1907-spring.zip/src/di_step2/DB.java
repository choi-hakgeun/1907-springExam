package di_step2;

public interface DB {
	public void getIrum();
}
