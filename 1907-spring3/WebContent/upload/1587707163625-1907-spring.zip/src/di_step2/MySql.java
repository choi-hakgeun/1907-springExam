package di_step2;

public class MySql implements DB {

	@Override
	public void getIrum() {
		System.out.println("kim...");

	}

}
