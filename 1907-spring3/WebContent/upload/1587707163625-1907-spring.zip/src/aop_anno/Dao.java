package aop_anno;

public interface Dao {
	public void select();
	public void view();
	public void modify();	
	public void insert();
	public void delete();
}
