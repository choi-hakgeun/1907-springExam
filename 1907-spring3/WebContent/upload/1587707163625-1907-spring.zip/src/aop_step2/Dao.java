package aop_step2;

public class Dao {
	public void select() {
		System.out.println("select...............");
	}
	public void view() {
		System.out.println("view...............");
	}
	public void modify() {
		System.out.println("modify...............");
	}
	
	public void insert() {
		System.out.println("insert...............");
	}
	public void delete() {
		System.out.println("delete...............");
	}
}
